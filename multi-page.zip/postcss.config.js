/**
 * Created by Administrator on 2018/2/2.
 */
module.exports = {
    plugins: [
        require('autoprefixer')
    ]
};
